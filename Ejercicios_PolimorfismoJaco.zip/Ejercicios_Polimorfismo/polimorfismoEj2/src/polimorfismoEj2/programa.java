package polimorfismoEj2;

import java.util.Scanner;

public class programa {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese la matrícula del coche: ");
        String matriculaCoche = scanner.nextLine();

        System.out.print("Ingrese el número de puertas del coche: ");
        int puertas = scanner.nextInt();
        Coche coche = new Coche(matriculaCoche, puertas);

        System.out.println("Ingrese cuánto desea acelerar el coche: ");
        int cantidadAcelerarCoche = scanner.nextInt();
        coche.acelerar(cantidadAcelerarCoche);

        System.out.println("Información del coche: ");
        System.out.println(coche);


        scanner.nextLine(); 
        System.out.print("Ingrese la matrícula del camión: ");
        String matriculaCamion = scanner.nextLine();

        Camion camion = new Camion(matriculaCamion);

        System.out.println("Ingrese el peso del remolque para el camión: ");
        int pesoRemolque = scanner.nextInt();
        Remolque remolque = new Remolque(pesoRemolque);
        camion.ponRemolque(remolque);

        System.out.println("Ingrese cuánto desea acelerar el camión: ");
        int cantidadAcelerarCamion = scanner.nextInt();
        camion.acelerar(cantidadAcelerarCamion);

        System.out.println("Información del camión: ");
        System.out.println(camion);

        scanner.close();
    }
}

