package polimorfismoEj2;

class Coche extends Vehiculo {
	
    private int numeroDePuertas;

    public Coche(String matricula, int numeroDePuertas) {
        super(matricula);  
        this.numeroDePuertas = numeroDePuertas;
    }

    public int getNumeroDePuertas() {
        return numeroDePuertas;
    }

    @Override
    public String toString() {
        return super.toString() + ", Número de puertas: " + numeroDePuertas;
    }
}