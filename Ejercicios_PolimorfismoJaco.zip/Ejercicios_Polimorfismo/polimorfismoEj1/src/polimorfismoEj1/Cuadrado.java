package polimorfismoEj1;

public class Cuadrado extends FiguraGeometrica {

    public Cuadrado(int lado) {
        super(lado);
    }

    public double getArea() {
        return valor1 * valor1;
    }

    public double getPerimetro() {
        return 4 * valor1;
    }
}
