package polimorfismoEj1;
import java.util.Scanner;

public class programa {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el radio del círculo: ");
        int radio = scanner.nextInt();
        Circulo circulo = new Circulo(radio);
        System.out.println("Área del círculo: " + circulo.getArea());
        System.out.println("Perímetro del círculo: " + circulo.getPerimetro());

        System.out.print("Ingrese el lado del cuadrado: ");
        int ladoCuadrado = scanner.nextInt();
        Cuadrado cuadrado = new Cuadrado(ladoCuadrado);
        System.out.println("Área del cuadrado: " + cuadrado.getArea());
        System.out.println("Perímetro del cuadrado: " + cuadrado.getPerimetro());

        System.out.print("Ingrese el lado del cubo: ");
        int ladoCubo = scanner.nextInt();
        Cubo cubo = new Cubo(ladoCubo);
        System.out.println("Área del cubo: " + cubo.getArea());

        System.out.print("Ingrese el largo del rectángulo: ");
        int largo = scanner.nextInt();
        System.out.print("Ingrese el ancho del rectángulo: ");
        int ancho = scanner.nextInt();
        Rectangulo rectangulo = new Rectangulo(largo, ancho);
        System.out.println("Área del rectángulo: " + rectangulo.getArea());
        System.out.println("Perímetro del rectángulo: " + rectangulo.getPerimetro());

        System.out.print("Ingrese la base del triángulo: ");
        int base = scanner.nextInt();
        System.out.print("Ingrese la altura del triángulo: ");
        int altura = scanner.nextInt();
        Triangulo triangulo = new Triangulo(base, altura);
        System.out.println("Área del triángulo: " + triangulo.getArea());
        System.out.println("Perímetro del triángulo (suponiendo que es equilátero): " + triangulo.getPerimetro());
    }
}
