package PackageEmpleado;

import java.util.ArrayList;

class Empleado {
    protected String nombre;
    protected String apellidos;
    protected String dni;
    protected String direccion;
    protected String telefono;
    protected double salario;
    protected int antiguedad;
    protected Empleado supervisor;

    public Empleado(String nombre, String apellidos, String dni, String direccion, String telefono, double salario) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.dni = dni;
        this.direccion = direccion;
        this.telefono = telefono;
        this.salario = salario;
        this.antiguedad = 0;  
    }

    public void imprimir() {
        System.out.println("Nombre: " + nombre + " " + apellidos);
        System.out.println("DNI: " + dni);
        System.out.println("Dirección: " + direccion);
        System.out.println("Teléfono: " + telefono);
        System.out.println("Salario: " + salario);
        System.out.println("Antigüedad: " + antiguedad + " años");
        if (supervisor != null) {
            System.out.println("Supervisor: " + supervisor.nombre + " " + supervisor.apellidos);
        }
    }

    public void cambiarSupervisor(Empleado nuevoSupervisor) {
        this.supervisor = nuevoSupervisor;
    }

    public void incrementarSalario(double porcentaje) {
        salario += salario * porcentaje / 100;
    }

    
    public double salarioEnUnAno() {
        return salario; 
    }
}

