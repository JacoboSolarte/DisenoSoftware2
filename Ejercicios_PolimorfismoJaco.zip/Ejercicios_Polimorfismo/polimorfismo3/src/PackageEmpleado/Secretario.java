package PackageEmpleado;

class Secretario extends Empleado {
    private String despacho;
    private String numeroFax;

    public Secretario(String nombre, String apellidos, String dni, String direccion, String telefono, double salario, String despacho, String numeroFax) {
        super(nombre, apellidos, dni, direccion, telefono, salario);
        this.despacho = despacho;
        this.numeroFax = numeroFax;
    }

    @Override
    public void imprimir() {
        super.imprimir();
        System.out.println("Puesto: Secretario");
        System.out.println("Despacho: " + despacho);
        System.out.println("Número de fax: " + numeroFax);
    }

    @Override
    public void incrementarSalario(double porcentaje) {
        super.incrementarSalario(5);  
    }

    @Override
    public double salarioEnUnAno() {
        return salario * 1.05; 
    }
}