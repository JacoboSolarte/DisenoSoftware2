package PackageEmpleado;

import java.util.ArrayList;
import java.util.List;

class Vendedor extends Empleado {
    private String matriculaCoche;
    private String marcaCoche;
    private String modeloCoche;
    private String areaVenta;
    private ArrayList<String> listaClientes;
    private double porcentajeComision;

    public Vendedor(String nombre, String apellidos, String dni, String direccion, String telefono, double salario, String matriculaCoche, String marcaCoche, String modeloCoche, String areaVenta, double porcentajeComision) {
        super(nombre, apellidos, dni, direccion, telefono, salario);
        this.matriculaCoche = matriculaCoche;
        this.marcaCoche = marcaCoche;
        this.modeloCoche = modeloCoche;
        this.areaVenta = areaVenta;
        this.porcentajeComision = porcentajeComision;
        this.listaClientes = new ArrayList<>();
    }

    public void agregarCliente(String cliente) {
        listaClientes.add(cliente);
    }

    public void eliminarCliente(String cliente) {
        listaClientes.remove(cliente);
    }

    public void cambiarCoche(String matricula, String marca, String modelo) {
        this.matriculaCoche = matricula;
        this.marcaCoche = marca;
        this.modeloCoche = modelo;
    }

    @Override
    public void imprimir() {
        super.imprimir();
        System.out.println("Puesto: Vendedor");
        System.out.println("Coche: " + marcaCoche + " " + modeloCoche + " (Matrícula: " + matriculaCoche + ")");
        System.out.println("Área de venta: " + areaVenta);
        System.out.println("Clientes: " + listaClientes);
    }

    @Override
    public void incrementarSalario(double porcentaje) {
        super.incrementarSalario(10); 
    }

    @Override
    public double salarioEnUnAno() {
        return salario * 1.10; 
    }
}