package PackageEmpleado;

import java.util.Scanner;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        // Crear empleados
	        Secretario secretario = new Secretario("Ana", "Gómez", "12345678A", "Calle Falsa 123", "555-1234", 25000, "Despacho 101", "555-4321");
	        Secretario secretario1 = new Secretario("Valentina", "Gómez", "12345678A", "Calle Falsa 123", "555-1234", 25000, "Despacho 101", "555-4321");
	        Vendedor vendedor = new Vendedor("Carlos", "Pérez", "23456789B", "Avenida Siempre Viva 742", "555-5678", 30000, "1234-XYZ", "Toyota", "Corolla", "Norte", 5);
	        JefeZona jefeZona = new JefeZona("Laura", "Rodríguez", "34567890C", "Calle Central 456", "555-9876", 50000, "5678-ABC", "BMW", "Serie 5");
	        JefeZona jefeZona1 = new JefeZona("Jeroniom", "Rodríguez", "34567890C", "Calle Central 456", "555-9876", 50000, "5678-ABC", "BMW", "Serie 5");
	        
	        
	        // Asignar supervisor
	        vendedor.cambiarSupervisor(secretario);
	        jefeZona.cambiarSecretario(secretario);
	        jefeZona.agregarVendedor(vendedor);
	        jefeZona1.agregarVendedor(vendedor);
	        jefeZona1.cambiarSecretario(secretario1);
	        
	        // Interacción con el usuario
	        int opcion;
	        do {
	            System.out.println("\n--- Menú de Empresa ---");
	            System.out.println("1. Mostrar datos de Secretario");
	            System.out.println("2. Mostrar datos de Vendedor");
	            System.out.println("3. Mostrar datos de Jefe de Zona");
	            System.out.println("4. Incrementar salario de Secretario");
	            System.out.println("5. Incrementar salario de Vendedor");
	            System.out.println("6. Incrementar salario de Jefe de Zona");
	            System.out.println("7. Cambiar coche de Vendedor");
	            System.out.println("8. Cambiar coche de Jefe de Zona");
	            System.out.println("9. Cambiar Secretario de Jefe de Zona");
	            System.out.println("10. Cambiar Supervisor de Vendedor");
	            System.out.println("11. Mostrar salario proyectado en un año");
	            System.out.println("12. Salir");
	            System.out.print("Seleccione una opción: ");
	            opcion = scanner.nextInt();

	            switch (opcion) {
	                case 1:
	                    secretario.imprimir();
	                    secretario1.imprimir();
	                    break;
	                case 2:
	                    vendedor.imprimir();
	                    break;
	                case 3:
	                    jefeZona.imprimir();
	                    jefeZona1.imprimir();
	                    break;
	                case 4:
	                    secretario.incrementarSalario(5);
	                    System.out.println("Salario del secretario incrementado.");
	                    break;
	                case 5:
	                    vendedor.incrementarSalario(10);
	                    System.out.println("Salario del vendedor incrementado.");
	                    break;
	                case 6:
	                    jefeZona.incrementarSalario(20);
	                    System.out.println("Salario del jefe de zona incrementado.");
	                    break;
	                case 7:
	                    System.out.print("Ingrese nueva matrícula del coche: ");
	                    String nuevaMatriculaVendedor = scanner.next();
	                    System.out.print("Ingrese nueva marca del coche: ");
	                    String nuevaMarcaVendedor = scanner.next();
	                    System.out.print("Ingrese nuevo modelo del coche: ");
	                    String nuevoModeloVendedor = scanner.next();
	                    vendedor.cambiarCoche(nuevaMatriculaVendedor, nuevaMarcaVendedor, nuevoModeloVendedor);
	                    System.out.println("Coche del vendedor cambiado.");
	                    break;
	                case 8:
	                    System.out.print("Ingrese nueva matrícula del coche: ");
	                    String nuevaMatriculaJefe = scanner.next();
	                    System.out.print("Ingrese nueva marca del coche: ");
	                    String nuevaMarcaJefe = scanner.next();
	                    System.out.print("Ingrese nuevo modelo del coche: ");
	                    String nuevoModeloJefe = scanner.next();
	                    jefeZona.cambiarCoche(nuevaMatriculaJefe, nuevaMarcaJefe, nuevoModeloJefe);
	                    System.out.println("Coche del jefe de zona cambiado.");
	                    break;
	                case 9:
	                    System.out.print("Ingrese nombre del nuevo secretario: ");
	                    String nombreSecretario = scanner.next();
	                    System.out.print("Ingrese apellidos del nuevo secretario: ");
	                    String apellidosSecretario = scanner.next();
	                    System.out.print("Ingrese DNI del nuevo secretario: ");
	                    String dniSecretario = scanner.next();
	                    System.out.print("Ingrese dirección del nuevo secretario: ");
	                    String direccionSecretario = scanner.next();
	                    System.out.print("Ingrese teléfono del nuevo secretario: ");
	                    String telefonoSecretario = scanner.next();
	                    System.out.print("Ingrese salario del nuevo secretario: ");
	                    double salarioSecretario = scanner.nextDouble();
	                    Secretario nuevoSecretario = new Secretario(nombreSecretario, apellidosSecretario, dniSecretario, direccionSecretario, telefonoSecretario, salarioSecretario, "Despacho 202", "555-0000");
	                    jefeZona.cambiarSecretario(nuevoSecretario);
	                    System.out.println("Secretario del jefe de zona cambiado.");
	                    break;
	                case 10:
	                    System.out.print("Ingrese nombre del nuevo supervisor: ");
	                    String nombreSupervisor = scanner.next();
	                    System.out.print("Ingrese apellidos del nuevo supervisor: ");
	                    String apellidosSupervisor = scanner.next();
	                    System.out.print("Ingrese DNI del nuevo supervisor: ");
	                    String dniSupervisor = scanner.next();
	                    System.out.print("Ingrese dirección del nuevo supervisor: ");
	                    String direccionSupervisor = scanner.next();
	                    System.out.print("Ingrese teléfono del nuevo supervisor: ");
	                    String telefonoSupervisor = scanner.next();
	                    System.out.print("Ingrese salario del nuevo supervisor: ");
	                    double salarioSupervisor = scanner.nextDouble();
	                    Empleado nuevoSupervisor = new Empleado(nombreSupervisor, apellidosSupervisor, dniSupervisor, direccionSupervisor, telefonoSupervisor, salarioSupervisor);
	                    vendedor.cambiarSupervisor(nuevoSupervisor);
	                    System.out.println("Supervisor del vendedor cambiado.");
	                    break;
	                case 11:
	                    System.out.printf("Salario proyectado del secretario en un año: %.2f\n", secretario.salarioEnUnAno());
	                    System.out.printf("Salario proyectado del vendedor en un año: %.2f\n", vendedor.salarioEnUnAno());
	                    System.out.printf("Salario proyectado del jefe de zona en un año: %.2f\n", jefeZona.salarioEnUnAno());
	                    break;
	                case 12:
	                    System.out.println("Saliendo del programa...");
	                    break;
	                default:
	                    System.out.println("Opción no válida.");
	                    break;
	            }
	        } while (opcion != 12);

	        scanner.close();
	    }
	}