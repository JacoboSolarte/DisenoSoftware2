package PackageEmpleado;

import java.util.ArrayList;
import java.util.List; 	 

class JefeZona extends Empleado {
    private Secretario secretario;
    private ArrayList<Vendedor> vendedores;
    private String matriculaCoche;
    private String marcaCoche;
    private String modeloCoche;

    public JefeZona(String nombre, String apellidos, String dni, String direccion, String telefono, double salario, String matriculaCoche, String marcaCoche, String modeloCoche) {
        super(nombre, apellidos, dni, direccion, telefono, salario);
        this.matriculaCoche = matriculaCoche;
        this.marcaCoche = marcaCoche;
        this.modeloCoche = modeloCoche;
        this.vendedores = new ArrayList<>();
    }

    public void cambiarSecretario(Secretario nuevoSecretario) {
        this.secretario = nuevoSecretario;
    }

    public void agregarVendedor(Vendedor vendedor) {
        vendedores.add(vendedor);
    }

    public void eliminarVendedor(Vendedor vendedor) {
        vendedores.remove(vendedor);
    }

    public void cambiarCoche(String matricula, String marca, String modelo) {
        this.matriculaCoche = matricula;
        this.marcaCoche = marca;
        this.modeloCoche = modelo;
    }

    @Override
    public void imprimir() {
        super.imprimir();
        System.out.println("Puesto: Jefe de Zona");
        System.out.println("Secretario: " + (secretario != null ? secretario.nombre : "Sin secretario"));
        System.out.println("Coche: " + marcaCoche + " " + modeloCoche + " (Matrícula: " + matriculaCoche + ")");
        System.out.println("Vendedores a cargo: " + vendedores.size());
    }

    @Override
    public void incrementarSalario(double porcentaje) {
        super.incrementarSalario(20);  
    }

    @Override
    public double salarioEnUnAno() {
        return salario * 1.20; 
    }
}